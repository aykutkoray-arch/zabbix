/*
 * MIT License
 * Copyright (c) 2025 ObviousAIChicken
 * Modified for Multi-Host Support
 */

class CWidgetHostOverviewMulti extends CWidget {
  onInitialize() {
    this.rendered = false;
    // State for interface tickers per host
    this.interfaceTicker = new Map();
    // State for percent tickers per host
    this.percentTicker = new Map();
  }

  // Toggle a class on the container div if the header is hidden
  updateViewModeAttr() {
    try {
      if (!this._body) return;
      const container = this._body.querySelector("#hosts-container");
      if (!container) return;
      if (typeof this.getViewMode === "function") {
        const mode = this.getViewMode();
        container.classList.toggle("hidden_header", mode);
      }
    } catch (_) {}
  }

  // Set width and color for a fill element
  updateFillWidth(element, percent, fields = null) {
    if (!element) return;
    const p = Number(percent);
    const targetWidth = `${p}%`;
    element.style.width = targetWidth;

    // Apply color directly from config fields if available
    if (!fields) return;

    if (fields["color_scheme"] == "1") {
      element.style.backgroundColor = `#${fields["fill_color"]}`;
    } else {
      const highThreshold = Number(fields["th_num_1"]);
      const mediumThreshold = Number(fields["th_num_2"]);
      if (p > highThreshold) {
        element.style.backgroundColor = `#${fields["th_color_1"]}`;
      } else if (p > mediumThreshold) {
        element.style.backgroundColor = `#${fields["th_color_2"]}`;
      } else {
        element.style.backgroundColor = `#${fields["th_color_3"]}`;
      }
    }
  }

  // Widget lifecycle
  setContents(response) {
    // Render the skeleton once then update values
    if (!this.rendered) {
      super.setContents(response);
      this.rendered = true;
      // Ensure the container reflects the current view mode
      this.updateViewModeAttr();
    }

    // If config and hosts_data are present update values
    if (response.config && response.hosts_data) {
      this.updateValues(response);
    }
  }

  // Update values in DOM for all hosts
  updateValues(response) {
    if (!response || !response.config || !response.hosts_data) return;

    // Keep container view mode in sync for styling
    this.updateViewModeAttr();

    const fields = response.config;

    // Helper for percent ticker
    const clampPercent = (n) => {
      const v = Math.round(Number(n) || 0);
      return Math.max(0, Math.min(100, v));
    };

    const startPercentTicker = (key, toPercent, textEl, showPercent = true) => {
      const state = this.percentTicker.get(key) || { value: 0, rafId: null };
      if (state.rafId) cancelAnimationFrame(state.rafId);
      const from = Number(state.value) || 0;
      const to = clampPercent(toPercent);
      const start = performance.now();
      const dur = 500;
      const step = (now) => {
        const t = Math.min(1, (now - start) / dur);
        const ease = 1 - Math.pow(1 - t, 3);
        const cur = Math.round(from + (to - from) * ease);
        if (textEl && showPercent) textEl.textContent = `${cur}%`;
        state.value = cur;
        if (t < 1) {
          state.rafId = requestAnimationFrame(step);
        } else {
          state.value = to;
          state.rafId = null;
          if (textEl && showPercent) textEl.textContent = `${to}%`;
        }
      };
      state.rafId = requestAnimationFrame(step);
      this.percentTicker.set(key, state);
    };

    // Helper to format bitrate
    const formatBits = (bps) => {
      const v = Math.max(0, Number(bps) || 0);
      if (v < 1_000_000) {
        let k = Math.floor(v / 1_000);
        if (k >= 1000) k = 999;
        return `${k} Kbps`;
      }
      if (v < 1_000_000_000) return `${(v / 1_000_000).toFixed(2)} Mbps`;
      return `${(v / 1_000_000_000).toFixed(2)} Gbps`;
    };

    // Interface ticker
    const startInterfaceTicker = (key, name, bps, percent, textEl, fillEl) => {
      const state = this.interfaceTicker.get(key) || {
        value: 0,
        rafId: null,
      };
      if (state.rafId) cancelAnimationFrame(state.rafId);

      const from = Number(state.value) || 0;
      const to = Number(bps) || 0;
      const start = performance.now();
      const dur = 700;

      if (fillEl && Number.isFinite(Number(percent))) {
        this.updateFillWidth(fillEl, Number(percent), fields);
      }

      const label = String(name);
      const step = (now) => {
        const t = Math.min(1, (now - start) / dur);
        const ease = 1 - Math.pow(1 - t, 3);
        const cur = from + (to - from) * ease;
        if (textEl) textEl.textContent = `${label} ${formatBits(cur)}`;
        state.value = cur;
        if (t < 1) {
          state.rafId = requestAnimationFrame(step);
        } else {
          state.value = to;
          state.rafId = null;
          if (textEl) textEl.textContent = `${label} ${formatBits(to)}`;
        }
      };
      state.rafId = requestAnimationFrame(step);
      this.interfaceTicker.set(key, state);
    };

    // Process each host card
    response.hosts_data.forEach((host) => {
      const hostid = host.hostid;
      const card = this._body.querySelector(`[data-hostid="${hostid}"]`);
      if (!card) return;

      // CPU
      if (fields["cpu_show"]) {
        const fill = card.querySelector(".cpu");
        const valueEl = card.querySelector(".cpu-value");
        const percent = Number(host.cpu);
        if (fill && Number.isFinite(percent)) {
          this.updateFillWidth(fill, percent, fields);
          if (valueEl) {
            startPercentTicker(`${hostid}:cpu`, percent, valueEl);
          }
        }
      }

      // RAM
      if (fields["ram_show"]) {
        const fill = card.querySelector(".ram");
        const valueEl = card.querySelector(".ram-value");
        const percent = Number(host.ram);
        if (fill && Number.isFinite(percent)) {
          this.updateFillWidth(fill, percent, fields);
          if (valueEl) {
            startPercentTicker(`${hostid}:ram`, percent, valueEl);
          }
        }
      }

      // Load
      if (fields["load_show"]) {
        const fill = card.querySelector(".load");
        const valueEl = card.querySelector(".load-value");
        const percent = Number(host.load_percent);
        if (fill && Number.isFinite(percent)) {
          this.updateFillWidth(fill, percent, fields);
          if (valueEl) {
            const loadValue = Number(host.load || 0).toFixed(2);
            valueEl.textContent = loadValue;
          }
        }
      }

      // Interfaces
      if (fields["interfaces_show"] && host.interfaces) {
        for (const name in host.interfaces) {
          const item = host.interfaces[name] || {};
          const cell = card.querySelector(
            `.multi-cell[data-key="${CSS.escape(name)}"]`
          );
          if (!cell) continue;

          const fill = cell.querySelector(".metric-fill");
          const text = cell.querySelector(".multi-text");
          const bps = item.bps || 0;
          const percent = item.percent || 0;

          startInterfaceTicker(
            `${hostid}:if:${name}`,
            name,
            bps,
            percent,
            text,
            fill
          );
        }
      }

      // Disks
      if (fields["disks_show"] && host.disks) {
        host.disks.forEach((disk) => {
          const cell = card.querySelector(
            `.multi-cell[data-key="${CSS.escape(disk.name)}"]`
          );
          if (!cell) return;

          const fill = cell.querySelector(".metric-fill");
          const text = cell.querySelector(".multi-text");
          const percent = Number(disk.percent);

          if (fill && Number.isFinite(percent)) {
            this.updateFillWidth(fill, percent, fields);
          }
          if (text) {
            startPercentTicker(
              `${hostid}:disk:${disk.name}`,
              percent,
              text
            );
          }
        });
      }

      // Partitions
      if (fields["partitions_show"] && host.partitions) {
        host.partitions.forEach((partition) => {
          const cell = card.querySelector(
            `.multi-cell[data-key="${CSS.escape(partition.name)}"]`
          );
          if (!cell) return;

          const fill = cell.querySelector(".metric-fill");
          const text = cell.querySelector(".multi-text");
          const percent = Number(partition.percent);

          if (fill && Number.isFinite(percent)) {
            this.updateFillWidth(fill, percent, fields);
          }
          if (text) {
            startPercentTicker(
              `${hostid}:part:${partition.name}`,
              percent,
              text
            );
          }
        });
      }
    });
  }
}
