<?php

/*
 * MIT License
 * Copyright (c) 2025 ObviousAIChicken
 * Modified for Multi-Host Support
 */

$view = new CWidgetView($data);

// Container
$container = (new CDiv())->setId('hosts-container')->addClass('hosts-grid');

// Build a card for each host
foreach (($data['hosts_data'] ?? []) as $host) {
    $hostid = $host['hostid'];
    $host_name = $host['name'];
    $status = $host['status'];
    
    // Host card
    $card = (new CDiv())
        ->addClass('host-card')
        ->setAttribute('data-hostid', $hostid)
        ->setAttribute('data-status', $status);
    
    // Host header with name and status indicator
    $header = (new CDiv())->addClass('host-header');
    
    // Host link to Zabbix host page
    $host_link = (new CLink($host_name, 'zabbix.php?action=host.view&filter_name=' . urlencode($host['host'])))
        ->addClass('host-name')
        ->setAttribute('target', '_blank');
    
    $status_icon = (new CTag('span', true))
        ->addClass('status-indicator')
        ->addClass('status-' . $status);
    
    $header->addItem($host_link);
    $header->addItem($status_icon);
    
    $card->addItem($header);
    
    // Metrics container
    $metrics = (new CDiv())->addClass('host-metrics');
    
    // CPU
    if ($data['config']['cpu_show']) {
        $metrics->addItem(
            (new CDiv())->addClass('metric-row')->addItem([
                (new CTag('span', true))->addClass('metric-label')->addItem('CPU'),
                (new CDiv())->addClass('metric-bar')->addItem(
                    (new CDiv())
                        ->addClass('metric-fill cpu')
                        ->setAttribute('data-percent', $host['cpu'])
                ),
                (new CTag('span', true))->addClass('metric-value cpu-value'),
            ])
        );
    }
    
    // RAM
    if ($data['config']['ram_show']) {
        $metrics->addItem(
            (new CDiv())->addClass('metric-row')->addItem([
                (new CTag('span', true))->addClass('metric-label')->addItem('RAM'),
                (new CDiv())->addClass('metric-bar')->addItem(
                    (new CDiv())
                        ->addClass('metric-fill ram')
                        ->setAttribute('data-percent', $host['ram'])
                ),
                (new CTag('span', true))->addClass('metric-value ram-value'),
            ])
        );
    }
    
    // Load
    if ($data['config']['load_show']) {
        $metrics->addItem(
            (new CDiv())->addClass('metric-row')->addItem([
                (new CTag('span', true))->addClass('metric-label')->addItem('Load'),
                (new CDiv())->addClass('metric-bar')->addItem(
                    (new CDiv())
                        ->addClass('metric-fill load')
                        ->setAttribute('data-percent', $host['load_percent'])
                        ->setAttribute('data-load', $host['load'])
                ),
                (new CTag('span', true))->addClass('metric-value load-value'),
            ])
        );
    }
    
    // Interfaces
    if ($data['config']['interfaces_show'] && !empty($host['interfaces'])) {
        $interfaces_container = (new CDiv())->addClass('metric-row multi-metric');
        $interfaces_label = (new CTag('span', true))->addClass('metric-label')->addItem('IF');
        $interfaces_data = (new CDiv())->addClass('metric-multi-data');
        
        foreach ($host['interfaces'] as $name => $vals) {
            $interfaces_data->addItem(
                (new CDiv())
                    ->addClass('multi-cell')
                    ->setAttribute('data-key', $name)
                    ->setAttribute('data-bps', $vals['bps'] ?? 0)
                    ->setAttribute('data-percent', $vals['percent'] ?? 0)
                    ->addItem((new CDiv())->addClass('metric-bar-small')->addItem((new CDiv())->addClass('metric-fill')))
                    ->addItem((new CTag('span'))->addClass('multi-text'))
            );
        }
        
        $interfaces_container->addItem($interfaces_label);
        $interfaces_container->addItem($interfaces_data);
        $metrics->addItem($interfaces_container);
    }
    
    // Disks
    if ($data['config']['disks_show'] && !empty($host['disks'])) {
        $disks_container = (new CDiv())->addClass('metric-row multi-metric');
        $disks_label = (new CTag('span', true))->addClass('metric-label')->addItem('Disk');
        $disks_data = (new CDiv())->addClass('metric-multi-data');
        
        foreach ($host['disks'] as $disk) {
            $disks_data->addItem(
                (new CDiv())
                    ->addClass('multi-cell')
                    ->setAttribute('data-key', $disk['name'])
                    ->setAttribute('data-percent', $disk['percent'])
                    ->addItem((new CDiv())->addClass('metric-bar-small')->addItem((new CDiv())->addClass('metric-fill')))
                    ->addItem((new CTag('span'))->addClass('multi-text'))
            );
        }
        
        $disks_container->addItem($disks_label);
        $disks_container->addItem($disks_data);
        $metrics->addItem($disks_container);
    }
    
    // Partitions
    if ($data['config']['partitions_show'] && !empty($host['partitions'])) {
        $partitions_container = (new CDiv())->addClass('metric-row multi-metric');
        $partitions_label = (new CTag('span', true))->addClass('metric-label')->addItem('Part');
        $partitions_data = (new CDiv())->addClass('metric-multi-data');
        
        foreach ($host['partitions'] as $partition) {
            $partitions_data->addItem(
                (new CDiv())
                    ->addClass('multi-cell')
                    ->setAttribute('data-key', $partition['name'])
                    ->setAttribute('data-percent', $partition['percent'])
                    ->addItem((new CDiv())->addClass('metric-bar-small')->addItem((new CDiv())->addClass('metric-fill')))
                    ->addItem((new CTag('span'))->addClass('multi-text'))
            );
        }
        
        $partitions_container->addItem($partitions_label);
        $partitions_container->addItem($partitions_data);
        $metrics->addItem($partitions_container);
    }
    
    $card->addItem($metrics);
    $container->addItem($card);
}

$view
    ->addItem($container)
    ->setVar('hosts_data', $data['hosts_data'] ?? [])
    ->setVar('config', $data['config'])
    ->show();
