<?php

/*
 * MIT License
 * Copyright (c) 2025 ObviousAIChicken
 * github.com/obviousaichicken/zabbix_widgets
 */

namespace Modules\HostOverviewMulti;

use Zabbix\Core\CWidget;

class Widget extends CWidget
{
}
